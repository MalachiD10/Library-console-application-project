﻿using LibraryManagementSystem;
using System;
using System.Linq;

namespace LibraryManagementSystem
{
    public static class Reports
    {
        public static void Menu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("============== REPORTS ==============");
                Console.ResetColor();

                Console.WriteLine("1. Library Summary");
                Console.WriteLine("2. Available Books");
                Console.WriteLine("3. Borrowed Books");
                Console.WriteLine("4. Overdue Books");
                Console.WriteLine("5. Fine Summary");
                Console.WriteLine("6. Search Books");
                Console.WriteLine("7. Search Members");
                Console.WriteLine("8. Return");

                Console.Write("\nChoice: ");

                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 8)
                    Console.Write("Enter 1-8: ");

                switch (choice)
                {
                    case 1: LibrarySummary(); break;
                    case 2: AvailableBooks(); break;
                    case 3: BorrowedBooks(); break;
                    case 4: OverdueBooks(); break;
                    case 5: FineSummary(); break;
                    case 6: BookManager.Menu(); break;
                    case 7: MemberManager.Menu(); break;
                }

            } while (choice != 8);
        }

        private static void LibrarySummary()
        {
            Console.Clear();

            int totalBooks = LibraryData.Books.Count;
            int available = LibraryData.Books.Count(b => b.IsAvailable);
            int borrowed = LibraryData.Books.Count(b => !b.IsAvailable);
            int members = LibraryData.Members.Count;
            int activeLoans = LibraryData.BorrowRecords.Count(r => r.ReturnDate == null);
            decimal fines = LibraryData.BorrowRecords.Sum(r => r.Fine);

            Console.WriteLine("=========== LIBRARY SUMMARY ===========");
            Console.WriteLine($"Total Books        : {totalBooks}");
            Console.WriteLine($"Available Books    : {available}");
            Console.WriteLine($"Borrowed Books     : {borrowed}");
            Console.WriteLine($"Registered Members : {members}");
            Console.WriteLine($"Active Loans       : {activeLoans}");
            Console.WriteLine($"Outstanding Fines  : R{fines:F2}");

            Pause();
        }

        private static void AvailableBooks()
        {
            Console.Clear();
            Console.WriteLine("AVAILABLE BOOKS\n");

            var books = LibraryData.Books.Where(b => b.IsAvailable).ToList();

            if (!books.Any())
            {
                Console.WriteLine("No available books.");
            }
            else
            {
                foreach (Book b in books)
                    Console.WriteLine($"{b.BookID} | {b.Title} | {b.Author} | {b.Category}");
            }

            Pause();
        }

        private static void BorrowedBooks()
        {
            Console.Clear();
            Console.WriteLine("BORROWED BOOKS\n");

            var records = LibraryData.BorrowRecords.Where(r => r.ReturnDate == null);

            if (!records.Any())
            {
                Console.WriteLine("No borrowed books.");
            }
            else
            {
                foreach (var r in records)
                {
                    Book b = LibraryData.Books.FirstOrDefault(x => x.BookID == r.BookID);
                    Console.WriteLine($"{r.BookID} | {b?.Title} | Member: {r.MemberID} | Due: {r.DueDate:d}");
                }
            }

            Pause();
        }

        private static void OverdueBooks()
        {
            Console.Clear();
            Console.WriteLine("OVERDUE BOOKS\n");

            var overdue = LibraryData.BorrowRecords.Where(r => r.ReturnDate == null && r.DueDate.Date < DateTime.Today);

            if (!overdue.Any())
            {
                Console.WriteLine("No overdue books.");
            }
            else
            {
                foreach (var r in overdue)
                {
                    int days = (DateTime.Today - r.DueDate.Date).Days;
                    Console.WriteLine($"{r.BookID} | Member {r.MemberID} | {days} day(s) overdue");
                }
            }

            Pause();
        }

        private static void FineSummary()
        {
            Console.Clear();

            Console.WriteLine("FINE SUMMARY\n");

            decimal total = 0;

            foreach (var r in LibraryData.BorrowRecords.Where(x => x.Fine > 0))
            {
                Console.WriteLine($"{r.MemberID} | {r.BookID} | R{r.Fine:F2}");
                total += r.Fine;
            }

            Console.WriteLine("\n--------------------------------");
            Console.WriteLine($"TOTAL FINES: R{total:F2}");

            Pause();
        }

        private static void Pause()
        {
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}