﻿using System;

namespace LibraryManagementSystem
{
    public class BorrowRecord
    {
        public int BorrowID { get; set; }

        public string MemberID { get; set; }

        public string BookID { get; set; }

        public DateTime BorrowDate { get; set; }

        public DateTime DueDate { get; set; }

        public DateTime? ReturnDate { get; set; }

        public decimal Fine { get; set; }

        public bool IsRenewed { get; set; }

        public BorrowRecord()
        {

        }

        public BorrowRecord(int borrowID, string memberID, string bookID)
        {
            BorrowID = borrowID;
            MemberID = memberID;
            BookID = bookID;

            BorrowDate = DateTime.Now;

            DueDate = BorrowDate.AddDays(7);

            ReturnDate = null;

            Fine = 0;

            IsRenewed = false;
        }

        public override string ToString()
        {
            string returned = ReturnDate.HasValue
                ? ReturnDate.Value.ToString("o")
                : "NULL";

            return $"{BorrowID}," +
                   $"{MemberID}," +
                   $"{BookID}," +
                   $"{BorrowDate:o}," +
                   $"{DueDate:o}," +
                   $"{returned}," +
                   $"{Fine}," +
                   $"{IsRenewed}";
        }

        public static BorrowRecord FromString(string line)
        {
            string[] data = line.Split(',');

            BorrowRecord record = new BorrowRecord();

            record.BorrowID = int.Parse(data[0]);

            record.MemberID = data[1];

            record.BookID = data[2];

            record.BorrowDate = DateTime.Parse(data[3]);

            record.DueDate = DateTime.Parse(data[4]);

            if (data[5] != "NULL")
                record.ReturnDate = DateTime.Parse(data[5]);

            record.Fine = decimal.Parse(data[6]);

            record.IsRenewed = bool.Parse(data[7]);

            return record;
        }
    }
}