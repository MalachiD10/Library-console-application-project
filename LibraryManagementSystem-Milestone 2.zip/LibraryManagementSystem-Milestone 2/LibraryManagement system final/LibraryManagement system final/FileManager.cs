﻿using LibraryManagementSystem;

using System;
using System.IO;

namespace LibraryManagementSystem
{
    public static class FileManager
    {
        // -----------------------------
        // BOOKS
        // -----------------------------
        public static void SaveBooks()
        {
            using (StreamWriter writer = new StreamWriter(LibraryData.BooksFile, false))
            {
                foreach (Book book in LibraryData.Books)
                {
                    writer.WriteLine(book.ToString());
                }
            }
        }

        public static void LoadBooks()
        {
            LibraryData.Books.Clear();

            if (!File.Exists(LibraryData.BooksFile))
                return;

            foreach (string line in File.ReadAllLines(LibraryData.BooksFile))
            {
                if (!string.IsNullOrWhiteSpace(line))
                    LibraryData.Books.Add(Book.FromString(line));
            }
        }

        // -----------------------------
        // MEMBERS
        // -----------------------------
        public static void SaveMembers()
        {
            using (StreamWriter writer = new StreamWriter(LibraryData.MembersFile, false))
            {
                foreach (Member member in LibraryData.Members)
                {
                    writer.WriteLine(member.ToString());
                }
            }
        }

        public static void LoadMembers()
        {
            LibraryData.Members.Clear();

            if (!File.Exists(LibraryData.MembersFile))
                return;

            foreach (string line in File.ReadAllLines(LibraryData.MembersFile))
            {
                if (!string.IsNullOrWhiteSpace(line))
                    LibraryData.Members.Add(Member.FromString(line));
            }
        }

        // -----------------------------
        // BORROW RECORDS
        // -----------------------------
        public static void SaveBorrowRecords()
        {
            using (StreamWriter writer = new StreamWriter(LibraryData.BorrowFile, false))
            {
                foreach (BorrowRecord record in LibraryData.BorrowRecords)
                {
                    string returnDate = record.ReturnDate.HasValue
                        ? record.ReturnDate.Value.ToString("o")
                        : "NULL";

                    writer.WriteLine(
                        $"{record.BorrowID}," +
                        $"{record.MemberID}," +
                        $"{record.BookID}," +
                        $"{record.BorrowDate:o}," +
                        $"{record.DueDate:o}," +
                        $"{returnDate}," +
                        $"{record.Fine}," +
                        $"{record.IsRenewed}");
                }
            }
        }

        public static void LoadBorrowRecords()
        {
            LibraryData.BorrowRecords.Clear();

            if (!File.Exists(LibraryData.BorrowFile))
                return;

            foreach (string line in File.ReadAllLines(LibraryData.BorrowFile))
            {
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                string[] data = line.Split(',');

                if (data.Length != 8)
                    continue;

                BorrowRecord record = new BorrowRecord();

                record.BorrowID = int.Parse(data[0]);
                record.MemberID = data[1];
                record.BookID = data[2];
                record.BorrowDate = DateTime.Parse(data[3]);
                record.DueDate = DateTime.Parse(data[4]);

                if (data[5] != "NULL")
                    record.ReturnDate = DateTime.Parse(data[5]);

                record.Fine = decimal.Parse(data[6]);
                record.IsRenewed = bool.Parse(data[7]);

                LibraryData.BorrowRecords.Add(record);
            }
        }

        // -----------------------------
        // INITIAL SAMPLE DATA
        // -----------------------------
        public static void SeedSampleBooks()
        {
            if (LibraryData.Books.Count > 0)
                return;

            LibraryData.Books.Add(new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald", "Fiction"));
            LibraryData.Books.Add(new Book("B002", "1984", "George Orwell", "Classic"));
            LibraryData.Books.Add(new Book("B003", "The Hobbit", "J.R.R. Tolkien", "Fantasy"));
            LibraryData.Books.Add(new Book("B004", "Harry Potter", "J.K. Rowling", "Fantasy"));
            LibraryData.Books.Add(new Book("B005", "The Alchemist", "Paulo Coelho", "Fiction"));

            SaveBooks();
        }

        public static void SeedSampleMembers()
        {
            if (LibraryData.Members.Count > 0)
                return;

            LibraryData.Members.Add(new Member("M001", "John Smith", "0821234567", "john@gmail.com"));
            LibraryData.Members.Add(new Member("M002", "Jane Adams", "0719876543", "jane@gmail.com"));

            SaveMembers();
        }
    }
}