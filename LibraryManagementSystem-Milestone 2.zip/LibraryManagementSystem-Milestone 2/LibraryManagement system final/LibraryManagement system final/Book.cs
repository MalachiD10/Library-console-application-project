﻿using System;

namespace LibraryManagementSystem
{
    public class Book
    {
        public string BookID { get; set; }

        public string Title { get; set; }

        public string Author { get; set; }

        public string Category { get; set; }

        public bool IsAvailable { get; set; }

        public Book()
        {

        }

        public Book(string id, string title, string author, string category)
        {
            BookID = id;
            Title = title;
            Author = author;
            Category = category;
            IsAvailable = true;
        }

        public override string ToString()
        {
            return $"{BookID},{Title},{Author},{Category},{IsAvailable}";
        }

        public static Book FromString(string line)
        {
            string[] data = line.Split(',');

            return new Book
            {
                BookID = data[0],
                Title = data[1],
                Author = data[2],
                Category = data[3],
                IsAvailable = bool.Parse(data[4])
            };
        }
    }
}
