﻿using System.Collections.Generic;

namespace LibraryManagementSystem
{
    public static class LibraryData
    {
        // Shared Lists

        public static List<Book> Books = new List<Book>();

        public static List<Member> Members = new List<Member>();

        public static List<BorrowRecord> BorrowRecords = new List<BorrowRecord>();


        // Data Files

        public static string BooksFile = "books.txt";

        public static string MembersFile = "members.txt";

        public static string BorrowFile = "borrowrecords.txt";
    }
}