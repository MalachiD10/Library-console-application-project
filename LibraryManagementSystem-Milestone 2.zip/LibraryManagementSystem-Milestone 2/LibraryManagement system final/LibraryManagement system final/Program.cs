﻿using System;

namespace LibraryManagementSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Load saved data when the application starts
            FileManager.LoadBooks();
            FileManager.LoadMembers();
            FileManager.LoadBorrowRecords();
            FileManager.SeedSampleBooks();
            FileManager.SeedSampleMembers();
            MainMenu();
        }

        static void MainMenu()
        {
            int choice;

            do
            {
                Console.Clear();

                Console.ForegroundColor = ConsoleColor.Cyan;

                Console.WriteLine("====================================================");
                Console.WriteLine("          COMMUNITY LIBRARY MANAGEMENT SYSTEM");
                Console.WriteLine("====================================================");

                Console.ResetColor();

                Console.WriteLine("1. Book Management");
                Console.WriteLine("2. Member Management");
                Console.WriteLine("3. Borrow / Return Books");
                Console.WriteLine("4. Reports");
                Console.WriteLine("5. Exit");

                Console.WriteLine();
                Console.Write("Enter your choice: ");

                while (!int.TryParse(Console.ReadLine(), out choice) ||
                       choice < 1 ||
                       choice > 5)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Invalid choice. Enter 1 - 5: ");
                    Console.ResetColor();
                }

                switch (choice)
                {
                    case 1:
                        BookManager.Menu();
                        break;

                    case 2:
                        MemberManager.Menu();
                        break;

                    case 3:
                        BorrowManager.Menu();
                        break;

                    case 4:
                        Reports.Menu();
                        break;

                    case 5:
                        ExitSystem();
                        break;
                }

            } while (choice != 5);
        }

        static void ExitSystem()
        {
            // Save all data before exiting
            FileManager.SaveBooks();
            FileManager.SaveMembers();
            FileManager.SaveBorrowRecords();

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine("======================================");
            Console.WriteLine(" Thank you for using the Library System");
            Console.WriteLine("======================================");

            Console.ResetColor();

            Console.WriteLine();
            Console.WriteLine("Goodbye!");

            Console.WriteLine();
            Console.WriteLine("Press any key to close...");

            Console.ReadKey();
        }
    }
}