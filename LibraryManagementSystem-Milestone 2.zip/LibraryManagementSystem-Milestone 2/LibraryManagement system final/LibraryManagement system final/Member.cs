﻿using System;

namespace LibraryManagementSystem
{
    public class Member
    {
        public string MemberID { get; set; }

        public string FullName { get; set; }

        public string ContactNumber { get; set; }

        public string EmailAddress { get; set; }

        public Member()
        {

        }

        public Member(string id, string name, string phone, string email)
        {
            MemberID = id;
            FullName = name;
            ContactNumber = phone;
            EmailAddress = email;
        }

        public override string ToString()
        {
            return $"{MemberID},{FullName},{ContactNumber},{EmailAddress}";
        }

        public static Member FromString(string line)
        {
            string[] data = line.Split(',');

            return new Member
            {
                MemberID = data[0],
                FullName = data[1],
                ContactNumber = data[2],
                EmailAddress = data[3]
            };
        }
    }
}