﻿
using System;
using System.Linq;

namespace LibraryManagementSystem
{
    public static class BookManager
    {
        public static void Menu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("=========== BOOK MANAGEMENT ===========");
                Console.ResetColor();

                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Update Book");
                Console.WriteLine("3. Delete Book");
                Console.WriteLine("4. Display Books");
                Console.WriteLine("5. Search Books");
                Console.WriteLine("6. Sort Books");
                Console.WriteLine("7. Return");
                Console.Write("\nChoice: ");

                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 7)
                    Console.Write("Enter 1-7: ");

                switch (choice)
                {
                    case 1: AddBook(); break;
                    case 2: UpdateBook(); break;
                    case 3: DeleteBook(); break;
                    case 4: DisplayBooks(); break;
                    case 5: SearchBooks(); break;
                    case 6: SortBooksMenu(); break;
                }
            } while (choice != 7);
        }

        private static void AddBook()
        {
            Console.Clear();
            Console.WriteLine("ADD BOOK");
            string id;
            while (true)
            {
                Console.Write("Book ID: ");
                id = Console.ReadLine().Trim().ToUpper();

                if (string.IsNullOrWhiteSpace(id))
                {
                    Console.WriteLine("Book ID cannot be empty.");
                    continue;
                }

                if (!id.StartsWith("B"))
                {
                    Console.WriteLine("Book ID must start with B.");
                    continue;
                }

                if (LibraryData.Books.Any(b => b.BookID == id))
                {
                    Console.WriteLine("Book ID already exists.");
                    continue;
                }
                break;
            }

            LibraryData.Books.Add(new Book(id,
                ReadRequired("Title"),
                ReadRequired("Author"),
                ReadRequired("Category")));

            FileManager.SaveBooks();
            Console.WriteLine("Book added successfully.");
            Pause();
        }

        private static void UpdateBook()
        {
            Console.Clear();
            Console.Write("Book ID: ");
            string id = Console.ReadLine().Trim().ToUpper();

            Book book = LibraryData.Books.FirstOrDefault(b => b.BookID == id);
            if (book == null)
            {
                Console.WriteLine("Book not found.");
                Pause();
                return;
            }

            Console.Write($"Title ({book.Title}): ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) book.Title = input.Trim();

            Console.Write($"Author ({book.Author}): ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) book.Author = input.Trim();

            Console.Write($"Category ({book.Category}): ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) book.Category = input.Trim();

            FileManager.SaveBooks();
            Console.WriteLine("Book updated.");
            Pause();
        }

        private static void DeleteBook()
        {
            Console.Clear();
            Console.Write("Book ID: ");
            string id = Console.ReadLine().Trim().ToUpper();

            Book book = LibraryData.Books.FirstOrDefault(b => b.BookID == id);
            if (book == null)
            {
                Console.WriteLine("Book not found.");
                Pause();
                return;
            }

            Console.Write($"Delete '{book.Title}'? (Y/N): ");
            if (Console.ReadLine().Trim().ToUpper() == "Y")
            {
                LibraryData.Books.Remove(book);
                FileManager.SaveBooks();
                Console.WriteLine("Book deleted.");
            }

            Pause();
        }

        private static void DisplayBooks()
        {
            Console.Clear();

            if (LibraryData.Books.Count == 0)
            {
                Console.WriteLine("No books found.");
                Pause();
                return;
            }

            Console.WriteLine("-----------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-8}{1,-30}{2,-25}{3,-18}{4,-12}",
                "ID", "TITLE", "AUTHOR", "CATEGORY", "STATUS");
            Console.WriteLine("-----------------------------------------------------------------------------------------------------");

            foreach (Book b in LibraryData.Books)
            {
                Console.WriteLine("{0,-8}{1,-30}{2,-25}{3,-18}{4,-12}",
                    b.BookID,
                    b.Title,
                    b.Author,
                    b.Category,
                    b.IsAvailable ? "Available" : "Borrowed");
            }

            Console.WriteLine("-----------------------------------------------------------------------------------------------------");
            Pause();
        }

        private static void SearchBooks()
        {
            Console.Clear();
            Console.WriteLine("SEARCH BOOKS");
            Console.WriteLine("1. Book ID");
            Console.WriteLine("2. Title");
            Console.WriteLine("3. Author");
            Console.WriteLine("4. Category");
            Console.Write("Choice: ");
            string choice = Console.ReadLine();

            Console.Write("Search: ");
            string search = Console.ReadLine();

            var results = LibraryData.Books.Where(book =>
            {
                switch (choice)
                {
                    case "1": return book.BookID.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    case "2": return book.Title.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    case "3": return book.Author.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    case "4": return book.Category.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    default: return false;
                }
            });

            Console.WriteLine();

            if (!results.Any())
            {
                Console.WriteLine("No matching books found.");
            }
            else
            {
                foreach (Book b in results)
                {
                    Console.WriteLine($"{b.BookID} | {b.Title} | {b.Author} | {b.Category} | {(b.IsAvailable ? "Available" : "Borrowed")}");
                }
            }

            Pause();
        }

        private static void SortBooksMenu()
        {
            Console.Clear();
            Console.WriteLine("SORT BOOKS");
            Console.WriteLine("1. Title");
            Console.WriteLine("2. Author");
            Console.WriteLine("3. Category");
            Console.Write("Choice: ");

            switch (Console.ReadLine())
            {
                case "1":
                    LibraryData.Books = LibraryData.Books.OrderBy(b => b.Title).ToList();
                    break;
                case "2":
                    LibraryData.Books = LibraryData.Books.OrderBy(b => b.Author).ToList();
                    break;
                case "3":
                    LibraryData.Books = LibraryData.Books.OrderBy(b => b.Category).ToList();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    Pause();
                    return;
            }

            FileManager.SaveBooks();
            Console.WriteLine("Books sorted successfully.");
            DisplayBooks();
        }

        private static string ReadRequired(string field)
        {
            string value;
            do
            {
                Console.Write(field + ": ");
                value = Console.ReadLine();
            } while (string.IsNullOrWhiteSpace(value));

            return value.Trim();
        }

        private static void Pause()
        {
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}