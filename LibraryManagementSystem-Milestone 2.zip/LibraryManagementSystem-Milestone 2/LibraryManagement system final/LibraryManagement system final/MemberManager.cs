﻿using LibraryManagementSystem;
using System;
using System.Linq;

namespace LibraryManagementSystem
{
    public static class MemberManager
    {
        public static void Menu()
        {
            int choice;

            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("=========== MEMBER MANAGEMENT ===========");
                Console.ResetColor();

                Console.WriteLine("1. Add Member");
                Console.WriteLine("2. Update Member");
                Console.WriteLine("3. Delete Member");
                Console.WriteLine("4. Display Members");
                Console.WriteLine("5. Search Members");
                Console.WriteLine("6. Return");

                Console.Write("\nChoice: ");

                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 6)
                    Console.Write("Enter 1-6: ");

                switch (choice)
                {
                    case 1: AddMember(); break;
                    case 2: UpdateMember(); break;
                    case 3: DeleteMember(); break;
                    case 4: DisplayMembers(); break;
                    case 5: SearchMembers(); break;
                }

            } while (choice != 6);
        }

        private static void AddMember()
        {
            Console.Clear();
            Console.WriteLine("ADD MEMBER");

            string memberID = GenerateMemberID();

            Console.WriteLine("Generated Member ID: " + memberID);

            string name = ReadRequired("Full Name");
            string phone = ReadPhone();
            string email = ReadEmail();

            LibraryData.Members.Add(new Member(memberID, name, phone, email));

            FileManager.SaveMembers();

            Console.WriteLine("\nMember added successfully.");
            Pause();
        }

        private static void UpdateMember()
        {
            Console.Clear();

            Console.Write("Member ID: ");
            string id = Console.ReadLine().Trim().ToUpper();

            Member member = LibraryData.Members.FirstOrDefault(m => m.MemberID == id);

            if (member == null)
            {
                Console.WriteLine("Member not found.");
                Pause();
                return;
            }

            Console.Write($"Name ({member.FullName}): ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
                member.FullName = input.Trim();

            Console.Write($"Phone ({member.ContactNumber}): ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
            {
                while (input.Length != 10 || !input.All(char.IsDigit))
                {
                    Console.Write("Enter a valid 10-digit phone: ");
                    input = Console.ReadLine();
                }
                member.ContactNumber = input;
            }

            Console.Write($"Email ({member.EmailAddress}): ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
            {
                while (!IsValidEmail(input))
                {
                    Console.Write("Enter a valid email: ");
                    input = Console.ReadLine();
                }
                member.EmailAddress = input;
            }

            FileManager.SaveMembers();

            Console.WriteLine("\nMember updated successfully.");
            Pause();
        }

        private static void DeleteMember()
        {
            Console.Clear();

            Console.Write("Member ID: ");
            string id = Console.ReadLine().Trim().ToUpper();

            Member member = LibraryData.Members.FirstOrDefault(m => m.MemberID == id);

            if (member == null)
            {
                Console.WriteLine("Member not found.");
                Pause();
                return;
            }

            Console.Write($"Delete {member.FullName}? (Y/N): ");

            if (Console.ReadLine().Trim().ToUpper() == "Y")
            {
                LibraryData.Members.Remove(member);
                FileManager.SaveMembers();
                Console.WriteLine("Member deleted.");
            }
            else
            {
                Console.WriteLine("Deletion cancelled.");
            }

            Pause();
        }

        private static void DisplayMembers()
        {
            Console.Clear();

            if (LibraryData.Members.Count == 0)
            {
                Console.WriteLine("No members registered.");
                Pause();
                return;
            }

            Console.WriteLine("--------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-8}{1,-30}{2,-15}{3,-35}",
                "ID", "NAME", "PHONE", "EMAIL");
            Console.WriteLine("--------------------------------------------------------------------------------------------");

            foreach (Member member in LibraryData.Members)
            {
                Console.WriteLine("{0,-8}{1,-30}{2,-15}{3,-35}",
                    member.MemberID,
                    member.FullName,
                    member.ContactNumber,
                    member.EmailAddress);
            }

            Console.WriteLine("--------------------------------------------------------------------------------------------");

            Pause();
        }

        private static void SearchMembers()
        {
            Console.Clear();

            Console.WriteLine("SEARCH MEMBERS");
            Console.WriteLine("1. Member ID");
            Console.WriteLine("2. Full Name");
            Console.Write("Choice: ");

            string option = Console.ReadLine();

            Console.Write("Search: ");
            string search = Console.ReadLine();

            var results = LibraryData.Members.Where(m =>
            {
                switch (option)
                {
                    case "1":
                        return m.MemberID.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    case "2":
                        return m.FullName.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
                    default:
                        return false;
                }
            });

            Console.WriteLine();

            if (!results.Any())
            {
                Console.WriteLine("No matching members found.");
            }
            else
            {
                foreach (Member m in results)
                {
                    Console.WriteLine($"{m.MemberID} | {m.FullName} | {m.ContactNumber} | {m.EmailAddress}");
                }
            }

            Pause();
        }

        private static string GenerateMemberID()
        {
            if (LibraryData.Members.Count == 0)
                return "M001";

            int highest = LibraryData.Members
                .Select(m => int.Parse(m.MemberID.Substring(1)))
                .Max();

            return "M" + (highest + 1).ToString("D3");
        }

        private static string ReadRequired(string field)
        {
            string value;
            do
            {
                Console.Write(field + ": ");
                value = Console.ReadLine();
            } while (string.IsNullOrWhiteSpace(value));

            return value.Trim();
        }

        private static string ReadPhone()
        {
            string phone;
            do
            {
                Console.Write("Phone Number: ");
                phone = Console.ReadLine();
            }
            while (phone.Length != 10 || !phone.All(char.IsDigit));

            return phone;
        }

        private static string ReadEmail()
        {
            string email;
            do
            {
                Console.Write("Email Address: ");
                email = Console.ReadLine();
            }
            while (!IsValidEmail(email));

            return email;
        }

        private static bool IsValidEmail(string email)
        {
            return !string.IsNullOrWhiteSpace(email)
                && email.Contains("@")
                && email.Contains(".");
        }

        private static void Pause()
        {
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}