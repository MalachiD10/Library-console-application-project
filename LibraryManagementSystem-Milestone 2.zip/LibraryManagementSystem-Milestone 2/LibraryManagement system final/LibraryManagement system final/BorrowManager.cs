﻿
using System;
using System.Linq;

namespace LibraryManagementSystem
{
    public static class BorrowManager
    {
        public static void Menu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("=========== BORROW MANAGEMENT ===========");
                Console.ResetColor();

                Console.WriteLine("1. Borrow Book");
                Console.WriteLine("2. Return Book");
                Console.WriteLine("3. Renew Loan");
                Console.WriteLine("4. View Active Loans");
                Console.WriteLine("5. Return");

                Console.Write("\nChoice: ");

                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 5)
                    Console.Write("Enter 1-5: ");

                switch (choice)
                {
                    case 1: BorrowBook(); break;
                    case 2: ReturnBook(); break;
                    case 3: RenewLoan(); break;
                    case 4: DisplayLoans(); break;
                }

            } while (choice != 5);
        }

        private static void BorrowBook()
        {
            Console.Clear();
            Console.Write("Member ID: ");
            string memberId = Console.ReadLine().Trim().ToUpper();

            Member member = LibraryData.Members.FirstOrDefault(m => m.MemberID == memberId);
            if (member == null)
            {
                Console.WriteLine("Member not found.");
                Pause();
                return;
            }

            Console.Write("Book ID: ");
            string bookId = Console.ReadLine().Trim().ToUpper();

            Book book = LibraryData.Books.FirstOrDefault(b => b.BookID == bookId);
            if (book == null)
            {
                Console.WriteLine("Book not found.");
                Pause();
                return;
            }

            if (!book.IsAvailable)
            {
                Console.WriteLine("Book is already borrowed.");
                Pause();
                return;
            }

            int nextId = LibraryData.BorrowRecords.Count == 0
                ? 1
                : LibraryData.BorrowRecords.Max(r => r.BorrowID) + 1;

            BorrowRecord record = new BorrowRecord(nextId, memberId, bookId);

            LibraryData.BorrowRecords.Add(record);
            book.IsAvailable = false;

            FileManager.SaveBooks();
            FileManager.SaveBorrowRecords();

            Console.WriteLine("\nBook borrowed successfully.");
            Console.WriteLine($"Borrow Date : {record.BorrowDate:d}");
            Console.WriteLine($"Due Date    : {record.DueDate:d}");
            Pause();
        }

        private static void ReturnBook()
        {
            Console.Clear();
            Console.Write("Book ID: ");
            string bookId = Console.ReadLine().Trim().ToUpper();

            BorrowRecord record = LibraryData.BorrowRecords
                .FirstOrDefault(r => r.BookID == bookId && r.ReturnDate == null);

            if (record == null)
            {
                Console.WriteLine("No active loan found.");
                Pause();
                return;
            }

            record.ReturnDate = DateTime.Now;
            record.Fine = CalculateFine(record.DueDate, record.ReturnDate.Value);

            Book book = LibraryData.Books.FirstOrDefault(b => b.BookID == bookId);
            if (book != null)
                book.IsAvailable = true;

            FileManager.SaveBooks();
            FileManager.SaveBorrowRecords();

            Console.WriteLine("\nBook returned successfully.");
            Console.WriteLine($"Fine Due: R{record.Fine:F2}");
            Pause();
        }

        private static void RenewLoan()
        {
            Console.Clear();
            Console.Write("Book ID: ");
            string bookId = Console.ReadLine().Trim().ToUpper();

            BorrowRecord record = LibraryData.BorrowRecords
                .FirstOrDefault(r => r.BookID == bookId && r.ReturnDate == null);

            if (record == null)
            {
                Console.WriteLine("Active loan not found.");
                Pause();
                return;
            }

            if (record.IsRenewed)
            {
                Console.WriteLine("Loan has already been renewed.");
                Pause();
                return;
            }

            record.DueDate = record.DueDate.AddDays(7);
            record.IsRenewed = true;

            FileManager.SaveBorrowRecords();

            Console.WriteLine("Loan renewed.");
            Console.WriteLine($"New Due Date: {record.DueDate:d}");
            Pause();
        }

        private static void DisplayLoans()
        {
            Console.Clear();

            var active = LibraryData.BorrowRecords.Where(r => r.ReturnDate == null).ToList();

            if (active.Count == 0)
            {
                Console.WriteLine("No active loans.");
                Pause();
                return;
            }

            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-6}{1,-10}{2,-10}{3,-15}{4,-15}{5,-10}",
                "ID", "MEMBER", "BOOK", "BORROWED", "DUE", "RENEWED");
            Console.WriteLine("------------------------------------------------------------------------------------------------");

            foreach (BorrowRecord r in active)
            {
                Console.WriteLine("{0,-6}{1,-10}{2,-10}{3,-15:d}{4,-15:d}{5,-10}",
                    r.BorrowID,
                    r.MemberID,
                    r.BookID,
                    r.BorrowDate,
                    r.DueDate,
                    r.IsRenewed ? "Yes" : "No");
            }

            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Pause();
        }

        private static decimal CalculateFine(DateTime dueDate, DateTime returnDate)
        {
            int lateDays = (returnDate.Date - dueDate.Date).Days;
            return lateDays > 0 ? lateDays * 5m : 0m;
        }

        private static void Pause()
        {
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}